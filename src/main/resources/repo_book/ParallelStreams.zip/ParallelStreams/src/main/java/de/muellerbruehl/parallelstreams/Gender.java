package de.muellerbruehl.parallelstreams;

public enum Gender {
  Male,
  Female;
}
